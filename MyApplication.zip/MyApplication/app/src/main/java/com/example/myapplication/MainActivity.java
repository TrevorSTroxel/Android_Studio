package com.example.myapplication;

import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.arch.core.internal.SafeIterableMap;
import androidx.collection.CircularIntArray;

import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.Random;

public class MainActivity extends AppCompatActivity implements Runnable
{
    int[] dice = {R.drawable.diceface1,R.drawable.diceface2,R.drawable.diceface3,R.drawable.diceface4,R.drawable.diceface5,R.drawable.diceface6};
    int[] images = {R.id.imageView, R.id.imageView2,R.id.imageView3,R.id.imageView4,R.id.imageView5};

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        Button b = findViewById(R.id.button2);
        b.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view) {
                GrabImages();
                Thread t = new Thread(MainActivity.this);
                t.start();
            }
        });

    }

    public void GrabImages()
    {
        ImageView I1 = findViewById(R.id.imageView);
        ViewAble(I1);
        ImageView I2 = findViewById(R.id.imageView2);
        ViewAble(I2);
        ImageView I3 = findViewById(R.id.imageView3);
        ViewAble(I3);
        ImageView I4 = findViewById(R.id.imageView4);
        ViewAble(I4);
        ImageView I5 = findViewById(R.id.imageView5);
        ViewAble(I5);
    }
    public void ViewAble(ImageView b)
    {
        b.setVisibility(View.VISIBLE);
    }

    @Override
    public void run() {
        try
        {
            int speed = 30;
            for(int i = 0; i < 20; i++)
            {
                changeDice();
                Thread.sleep(speed);
                speed += 10;
            }
        }
        catch (Exception ex) {;}

    }

    private void changeDice() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                for (Integer img : images) {
                    Random rnd = new Random();
                    int i = rnd.nextInt(dice.length);
                    ((ImageView) findViewById(img)).setImageResource(dice[i]);
                }
            }
        });
    }
}